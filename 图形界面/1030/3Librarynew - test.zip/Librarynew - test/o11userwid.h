#ifndef O11USERWID_H
#define O11USERWID_H

#include "elevenuserwid.h"
class O11userwid
{
public:
    O11userwid();
    static ElevenUserwid *p_obj11;
    static void Init();
};

#endif // O11USERWID_H
