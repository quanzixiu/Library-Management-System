#ifndef OBJTWOLOGIN_H
#define OBJTWOLOGIN_H

#include "twologind.h"
class Objtwologin
{
public:
    Objtwologin();
    static TwoLoginD * p_objtwo;
    static void Init();
};

#endif // OBJTWOLOGIN_H
