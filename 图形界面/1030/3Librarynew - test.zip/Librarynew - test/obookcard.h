#ifndef OBOOKCARD_H
#define OBOOKCARD_H

#include "usercradwid.h"
class ObookCard
{
public:
    ObookCard();
    static UserCradWid *p_objcard;
    static void Init();
};

#endif // OBOOKCARD_H
