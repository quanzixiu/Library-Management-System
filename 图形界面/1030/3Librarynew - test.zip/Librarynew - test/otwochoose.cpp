#include "otwochoose.h"

TwoChooseWid *Otwochoose ::p_otwochoose=NULL;
Otwochoose::Otwochoose()
{

}
void Otwochoose::Init()
{
    p_otwochoose=new TwoChooseWid();
}
