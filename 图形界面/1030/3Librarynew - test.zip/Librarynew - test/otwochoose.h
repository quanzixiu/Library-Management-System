#ifndef OTWOCHOOSE_H
#define OTWOCHOOSE_H

#include "twochoosewid.h"
class Otwochoose
{
public:
    Otwochoose();
    static TwoChooseWid *p_otwochoose;
    static void Init();
};

#endif // OTWOCHOOSE_H
