#ifndef OUSERBORROWED_H
#define OUSERBORROWED_H

#include "userborrowedwid.h"
class OuserBorrowed
{
public:
    OuserBorrowed();
    static UserBorrowedWid *p_oubored;
    static void Init();
};

#endif // OUSERBORROWED_H
