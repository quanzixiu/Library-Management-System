#include<iostream>
#include<string>
#include"supervisor.h"
#include"bookdocking.h"

string supervisor::DisplayBook(bookdocking& bd,int id) {
	string value;
    if (bd.bookexist(id))
        value = bd.booksearch(id);
	else 
		value = "The book dose not exist!";
	return value;
}
