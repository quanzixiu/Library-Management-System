#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"

string supervisor::DisplayUser(userdocking& ud,int id) {
    string value;
    if (ud.userexist(id)) {
        value = ud.usersearch(id);
		return value;
	}
	else {
		value = "The user does not exist!";
		return value;
	}
}
