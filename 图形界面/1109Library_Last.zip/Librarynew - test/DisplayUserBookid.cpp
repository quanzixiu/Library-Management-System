#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"
#include"userstatesdocking.h"

string supervisor::DisplayUserBookid(userdocking& ud,userstatesdocking& usd,int id) {
    string bookid;
    bookid = usd.ussearch(id);//��ǰ�û��Ľ�����Ϣ
	bookid = bookid.substr(0, 120);
	return bookid;
}
