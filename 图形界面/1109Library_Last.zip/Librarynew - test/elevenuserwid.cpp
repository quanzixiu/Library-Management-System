#include "elevenuserwid.h"
#include "ui_elevenuserwid.h"

#include "loginonewid.h"//登录界面
#include "ouserseek.h" //查找借阅界面
#include "ouserborrowed.h" //已借图书

#include "global.h"
ElevenUserwid::ElevenUserwid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ElevenUserwid)
{
    ui->setupUi(this);
}

ElevenUserwid::~ElevenUserwid()
{
    delete ui;
}

//显示查找借阅界面
void ElevenUserwid::on_seek_button_clicked()
{
    this->close();
    OuserSeek::p_oseek->show();
}
//显示已借图书界面
void ElevenUserwid::on_borrowed_button_clicked()
{
    this->close();
    OuserBorrowed::p_oubored->show();
}
//退出按钮：返回登录界面
void ElevenUserwid::on_relogin_button_clicked()
{
    this->close();
    Global::p.islogin=false;
    LoginOneWid *p_loginuser=new LoginOneWid();
    p_loginuser->show();
}
