#include "global.h"

bookdocking Global::bd;
userdocking Global::ud;
userstatesdocking Global::usd;
borrow Global::p;
Global::Global()
{

}
