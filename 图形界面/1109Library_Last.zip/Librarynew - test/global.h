#ifndef GLOBAL_H
#define GLOBAL_H

/*#include "bookdocking.h"
#include "userdocking.h"
#include "userstatesdocking.h"*/
#include "borrow.h"
class Global
{
public:
    Global();
    static bookdocking bd;
    static userdocking ud;
    static userstatesdocking usd;
    static borrow p;
};

#endif // GLOBAL_H
