#include "loginonewid.h"
#include "ui_loginonewid.h"

#include "o11userwid.h"//用户首页关联类
#include "otwochoose.h"//不同身份选择界面

#include "global.h"//全局变量test
LoginOneWid::LoginOneWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginOneWid)
{
    ui->setupUi(this);
    ui->id_linedit->clear();//1107test
    ui->password_linedit->clear();//1107test
    ui->password_linedit->setEchoMode(QLineEdit::Password);//设置密码样式
    ui->id_linedit->setMaxLength(6);
    ui->password_linedit->setMaxLength(16);
    QIntValidator *intValidator = new QIntValidator;
    this->ui->id_linedit->setValidator(intValidator);
}

LoginOneWid::~LoginOneWid()
{
    delete ui;
}
//得到用户账号
QString LoginOneWid::GetId()
{
    return ui->id_linedit->text();
}
//得到用户密码
QString LoginOneWid::GetPassword()
{
    return ui->password_linedit->text();
}

//确定按钮：验证用户登录
void LoginOneWid::on_login_button_clicked()
{
    int userid=ui->id_linedit->text().toInt();
    string password=ui->password_linedit->text().toStdString();
    //用户登录验证函数待填
    bool flag=false;
    flag=Global::p.qtlogin(userid,password,Global::ud);
    if(flag)
    {
            this->close();//login test
            O11userwid::p_obj11->show();
            ui->id_linedit->clear();//1107test
            ui->password_linedit->clear();//1107test
     }
     else
     {
       QMessageBox::warning(this,"警告","您输入的账号或密码有误");
       ui->id_linedit->clear();//1107test
       ui->password_linedit->clear();//1107test
     }
}
//退出登录按钮
void LoginOneWid::on_return_button_clicked()
{
    ui->id_linedit->clear();//1107test
    ui->password_linedit->clear();//1107test
    this->close();
    Global::p.islogin=false;
    Otwochoose::p_otwochoose->show();
}
