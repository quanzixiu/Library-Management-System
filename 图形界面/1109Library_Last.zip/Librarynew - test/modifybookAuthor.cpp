#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookAuthor(bookdocking& bd,int id, string author) {
    if (!bd.bookexist(id)) return false;
	else {
		author = dataformatting(4, author);
        if (bd.bookmodifyauthor(id, author))//1108test
			return true;
		else
			return false;
	}
}
