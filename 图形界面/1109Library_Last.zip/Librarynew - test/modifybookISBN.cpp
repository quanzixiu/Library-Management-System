#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookISBN(bookdocking& bd,int id,string ISBN) {
    if (!bd.bookexist(id)) return false;
	else {
		ISBN = dataformatting(6, ISBN);
        if (bd.bookmodifyISBN(id, ISBN))
			return true;
		else
			return false;
	}
}
