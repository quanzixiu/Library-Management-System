#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookIsovertime(bookdocking& bd,int id, string isovertime) {
    if (!bd.bookexist(id)) return false;
	else {
		isovertime = dataformatting(1, isovertime);
        if (bd.bookmodifyisovertime(id, isovertime))//1108test
			return true;
		else
			return false;
	}
}
