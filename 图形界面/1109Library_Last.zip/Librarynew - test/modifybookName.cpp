#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookName(bookdocking& bd,int id, string name) {

    if (!bd.bookexist(id)) return false;
	else {
		name = dataformatting(8, name);
        if (bd.bookmodifyname(id, name))//1107test
			return true;
		else
			return false;
	}
}
