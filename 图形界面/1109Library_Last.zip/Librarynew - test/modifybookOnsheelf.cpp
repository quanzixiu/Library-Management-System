#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookOnsheelf(bookdocking& bd,int id, string onsheelf) {
    if (!bd.bookexist(id)) return false;
	else {
		onsheelf = dataformatting(1, onsheelf);
        if (bd.bookmodifyonsheelf(id, onsheelf))//1108test
			return true;
		else
			return false;
	}
}
