#include<iostream>
#include"supervisor.h"
#include"bookdocking.h"
#include<string>

bool supervisor::modifybookType(bookdocking& bd,int id, string type) {

    if (!bd.bookexist(id)) return false;
	else {
		type = dataformatting(4, type);
        if (bd.bookmodifytype(id, type))
			return true;
		else
			return false;
	}
}
