#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"

bool supervisor::modifyuserCollege(userdocking& ud,int id, string college) {
    if (!ud.userexist(id))
		return false;
	else
	{
		college = dataformatting(4, college);
        if (ud.usermodifycollege(id, college))
			return true;
		else
			return false;
	}
}
