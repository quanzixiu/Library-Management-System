#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"


bool supervisor::modifyuserEmail(userdocking& ud,int id, string email) {

    if (!ud.userexist(id))
		return false;
	else
	{
		email = dataformatting(24, email);
        if (ud.usermodifyemail(id, email))
			return true;
		else
			return false;
	}
}
