#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"


bool supervisor::modifyuserMajor(userdocking& ud,int id, string major) {

    if (!ud.userexist(id))
		return false;
	else
	{
		major = dataformatting(4, major);
        if (ud.usermodifymajor(id, major))
			return true;
		else
			return false;
	}
}
