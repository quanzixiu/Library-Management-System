#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"

bool supervisor::modifyuserName(userdocking& ud,int id, string name) {

    if (!ud.userexist(id))
		return false;
	else
	{
		name = dataformatting(8, name);
        if (ud.usermodifyname(id, name))
			return true;
		else
			return false;
	}
}
