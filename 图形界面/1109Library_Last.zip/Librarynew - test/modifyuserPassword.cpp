#include<iostream>
#include<string>
#include"supervisor.h"
#include"userdocking.h"

bool supervisor::modifyuserPassword(userdocking& ud,int id, string password) {

    if (!ud.userexist(id))
		return false;
	else
	{
		password = dataformatting(16, password);
        if (ud.usermodifypassword(id, password))
			return true;
		else
			return false;
	}
}
