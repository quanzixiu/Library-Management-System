#include "ouserbrowse.h"

UserBrowseWid *OuserBrowse::p_browse=NULL;
OuserBrowse::OuserBrowse()
{

}
void OuserBrowse::Init()
{
    p_browse=new UserBrowseWid();
}
