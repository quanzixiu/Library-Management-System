#ifndef OUSERBROWSE_H
#define OUSERBROWSE_H

#include "userbrowsewid.h"
class OuserBrowse
{
public:
    OuserBrowse();
    static UserBrowseWid *p_browse;
    static void Init();
};

#endif // OUSERBROWSE_H
