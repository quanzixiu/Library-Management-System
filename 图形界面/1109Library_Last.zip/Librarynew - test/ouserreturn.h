#ifndef OUSERRETURN_H
#define OUSERRETURN_H

#include "userreturnwid.h"
#include <string>
class OuserReturn
{
public:
    OuserReturn();
    static UserReturnWid *p_oureturn;
    static void Init();
};

#endif // OUSERRETURN_H
