#ifndef OUSERSEEK_H
#define OUSERSEEK_H

#include "userseekmw.h"
class OuserSeek
{
public:
    OuserSeek();
    static UserSeekMw *p_oseek;//窗口指针
    static void Init();
};

#endif // OUSERSEEK_H
