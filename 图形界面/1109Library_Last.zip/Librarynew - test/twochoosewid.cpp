#include "twochoosewid.h"
#include "ui_twochoosewid.h"

#include "twologind.h"
#include "userreturnwid.h"
#include "loginonewid.h"
#include "objone.h"
TwoChooseWid::TwoChooseWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TwoChooseWid)
{
    ui->setupUi(this);
}

TwoChooseWid::~TwoChooseWid()
{
    delete ui;
}
//管理员系统
void TwoChooseWid::on_manager_button_clicked()
{
    this->close();
    TwoLoginD *p_manlogin=new TwoLoginD();
    p_manlogin->show();
}
//借阅系统
void TwoChooseWid::on_user_button_clicked()
{
    this->close();
    LoginOneWid *p_userlogin=new LoginOneWid();
    p_userlogin->show();
}
//还书系统
void TwoChooseWid::on_returnsystem_button_clicked()
{
    this->close();
    UserReturnWid *p_rebook=new UserReturnWid();
    p_rebook->show();
}
//关闭程序
void TwoChooseWid::on_return_button_clicked()
{
    this->close();
    Objone::p_objone->show();
    /*QApplication *app;
    app->quit();*/
}
