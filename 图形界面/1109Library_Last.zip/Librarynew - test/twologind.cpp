#include "twologind.h"
#include "ui_twologind.h"
#include "objone.h"
#include "o11userwid.h"
#include "otwochoose.h"

#include "supervisor.h"//管理员登录头文件
#include "chooseform.h"//显示管理员首页
TwoLoginD::TwoLoginD(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TwoLoginD)
{
    ui->setupUi(this);
    ui->password_linedit->setEchoMode(QLineEdit::Password);//1107设置密码样式
    ui->id_linedit->setFocus();
    ui->login_button->setDefault(true);
    QIntValidator *intValidator = new QIntValidator;
    this->ui->id_linedit->setValidator(intValidator);
}
//返回用户输入的ID
QString TwoLoginD::GetId()
{
    return ui->id_linedit->text();
}
//返回用户输入的password
QString TwoLoginD::GetPassword()
{
    return ui->password_linedit->text();
}

TwoLoginD::~TwoLoginD()
{
    delete ui;
}
//管理员登录
void TwoLoginD::on_login_button_clicked()
{
    ui->id_linedit->setMaxLength(6);
    if(ui->id_linedit->text().size()>8||ui->id_linedit->text().isEmpty()||ui->password_linedit->text().isEmpty())
    {
        QMessageBox::information(this,"提示","您还没有输入账号或密码");
        ui->id_linedit->setFocus();//鼠标定位到当前位置？
    }
    supervisor s;
    int supervisorid=ui->id_linedit->text().toInt();
    string password=ui->password_linedit->text().toStdString();
    bool flag=s.login(supervisorid,password);
    if(flag)
    {
            QDialog::accept();
            MainPage *p=new MainPage();
            p->show();
     }
     else
     {
            QMessageBox::warning(this,"账号或密码错误","请重新输入");
            ui->id_linedit ->clear();
            ui->password_linedit ->clear();
            ui->id_linedit ->setFocus();
      }
}
//退出登录按钮：返回不同身份选择界面
void TwoLoginD::on_return_button_clicked()
{
    QDialog::reject();
   Otwochoose::p_otwochoose->show();
}
