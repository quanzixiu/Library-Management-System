/********************************************************************************
** Form generated from reading UI file 'userborrowedwid.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERBORROWEDWID_H
#define UI_USERBORROWEDWID_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserBorrowedWid
{
public:
    QLabel *label;
    QPushButton *shouye_button;
    QPushButton *return_button;
    QTableWidget *borrowed_table;
    QPushButton *useridok_button;
    QLineEdit *stuid_linedit;

    void setupUi(QWidget *UserBorrowedWid)
    {
        if (UserBorrowedWid->objectName().isEmpty())
            UserBorrowedWid->setObjectName(QStringLiteral("UserBorrowedWid"));
        UserBorrowedWid->resize(1324, 851);
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        UserBorrowedWid->setFont(font);
        UserBorrowedWid->setAutoFillBackground(true);
        label = new QLabel(UserBorrowedWid);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(560, 30, 221, 81));
        QFont font1;
        font1.setPointSize(20);
        label->setFont(font1);
        shouye_button = new QPushButton(UserBorrowedWid);
        shouye_button->setObjectName(QStringLiteral("shouye_button"));
        shouye_button->setGeometry(QRect(1050, 180, 91, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        font2.setPointSize(14);
        font2.setBold(false);
        font2.setWeight(50);
        shouye_button->setFont(font2);
        shouye_button->setAutoFillBackground(true);
        return_button = new QPushButton(UserBorrowedWid);
        return_button->setObjectName(QStringLiteral("return_button"));
        return_button->setGeometry(QRect(1070, 750, 171, 61));
        QFont font3;
        font3.setPointSize(14);
        font3.setBold(false);
        font3.setWeight(50);
        return_button->setFont(font3);
        return_button->setAutoFillBackground(true);
        borrowed_table = new QTableWidget(UserBorrowedWid);
        if (borrowed_table->columnCount() < 7)
            borrowed_table->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        borrowed_table->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        borrowed_table->setObjectName(QStringLiteral("borrowed_table"));
        borrowed_table->setGeometry(QRect(140, 220, 1041, 491));
        useridok_button = new QPushButton(UserBorrowedWid);
        useridok_button->setObjectName(QStringLiteral("useridok_button"));
        useridok_button->setGeometry(QRect(780, 170, 101, 41));
        useridok_button->setFont(font3);
        stuid_linedit = new QLineEdit(UserBorrowedWid);
        stuid_linedit->setObjectName(QStringLiteral("stuid_linedit"));
        stuid_linedit->setGeometry(QRect(270, 170, 471, 31));
        QFont font4;
        font4.setPointSize(9);
        font4.setBold(false);
        font4.setWeight(50);
        stuid_linedit->setFont(font4);

        retranslateUi(UserBorrowedWid);

        QMetaObject::connectSlotsByName(UserBorrowedWid);
    } // setupUi

    void retranslateUi(QWidget *UserBorrowedWid)
    {
        UserBorrowedWid->setWindowTitle(QApplication::translate("UserBorrowedWid", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("UserBorrowedWid", "\345\267\262\345\200\237\344\271\246\347\261\215", Q_NULLPTR));
        shouye_button->setText(QApplication::translate("UserBorrowedWid", "\351\246\226\351\241\265", Q_NULLPTR));
        return_button->setText(QApplication::translate("UserBorrowedWid", "\351\200\200\345\207\272\347\231\273\345\275\225", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = borrowed_table->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("UserBorrowedWid", "ID", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = borrowed_table->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("UserBorrowedWid", "\344\271\246\345\220\215", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = borrowed_table->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("UserBorrowedWid", "ISBN", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = borrowed_table->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("UserBorrowedWid", "\344\275\234\350\200\205", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = borrowed_table->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("UserBorrowedWid", "\347\261\273\345\236\213", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = borrowed_table->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("UserBorrowedWid", "\345\200\237\344\271\246\346\227\245\346\234\237", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = borrowed_table->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("UserBorrowedWid", "\345\272\224\350\277\230\346\227\245\346\234\237", Q_NULLPTR));
        useridok_button->setText(QApplication::translate("UserBorrowedWid", "\347\241\256\345\256\232", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        stuid_linedit->setToolTip(QApplication::translate("UserBorrowedWid", "<html><head/><body><p>\347\224\250\346\210\267id</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        stuid_linedit->setWhatsThis(QApplication::translate("UserBorrowedWid", "<html><head/><body><p>\347\224\250\346\210\267id</p></body></html>", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
    } // retranslateUi

};

namespace Ui {
    class UserBorrowedWid: public Ui_UserBorrowedWid {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERBORROWEDWID_H
