/********************************************************************************
** Form generated from reading UI file 'userborrowwid.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERBORROWWID_H
#define UI_USERBORROWWID_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserBorrowWid
{
public:
    QLabel *label;
    QPushButton *seek_button;
    QPushButton *pushButton_2;
    QGroupBox *groupBox;
    QLineEdit *lineEdit;
    QPushButton *inok_button;
    QPushButton *borrowok_button;

    void setupUi(QWidget *UserBorrowWid)
    {
        if (UserBorrowWid->objectName().isEmpty())
            UserBorrowWid->setObjectName(QStringLiteral("UserBorrowWid"));
        UserBorrowWid->resize(783, 611);
        QFont font;
        font.setPointSize(14);
        UserBorrowWid->setFont(font);
        label = new QLabel(UserBorrowWid);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(220, 20, 111, 31));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setAutoFillBackground(true);
        seek_button = new QPushButton(UserBorrowWid);
        seek_button->setObjectName(QStringLiteral("seek_button"));
        seek_button->setGeometry(QRect(360, 60, 131, 51));
        seek_button->setAutoFillBackground(true);
        pushButton_2 = new QPushButton(UserBorrowWid);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(600, 540, 81, 31));
        pushButton_2->setAutoFillBackground(true);
        groupBox = new QGroupBox(UserBorrowWid);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(90, 130, 431, 371));
        QFont font2;
        font2.setPointSize(11);
        groupBox->setFont(font2);
        lineEdit = new QLineEdit(groupBox);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(80, 40, 161, 21));
        lineEdit->setAutoFillBackground(true);
        inok_button = new QPushButton(groupBox);
        inok_button->setObjectName(QStringLiteral("inok_button"));
        inok_button->setGeometry(QRect(260, 40, 51, 31));
        QFont font3;
        font3.setPointSize(9);
        inok_button->setFont(font3);
        inok_button->setAutoFillBackground(true);
        borrowok_button = new QPushButton(groupBox);
        borrowok_button->setObjectName(QStringLiteral("borrowok_button"));
        borrowok_button->setGeometry(QRect(140, 90, 111, 41));

        retranslateUi(UserBorrowWid);

        QMetaObject::connectSlotsByName(UserBorrowWid);
    } // setupUi

    void retranslateUi(QWidget *UserBorrowWid)
    {
        UserBorrowWid->setWindowTitle(QApplication::translate("UserBorrowWid", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("UserBorrowWid", "\345\200\237\351\230\205\344\271\246\347\261\215", Q_NULLPTR));
        seek_button->setText(QApplication::translate("UserBorrowWid", "\346\237\245\346\211\276\345\200\237\351\230\205\345\233\276\344\271\246", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("UserBorrowWid", "\351\200\200\345\207\272\347\231\273\345\275\225", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("UserBorrowWid", "\350\257\267\345\234\250\344\270\213\351\235\242\350\276\223\345\205\245\350\246\201\345\200\237\351\230\205\347\232\204\345\233\276\344\271\246ID(\350\207\263\345\244\232\344\270\2726\344\275\215)", Q_NULLPTR));
        inok_button->setText(QApplication::translate("UserBorrowWid", "\347\241\256\345\256\232", Q_NULLPTR));
        borrowok_button->setText(QApplication::translate("UserBorrowWid", "\347\241\256\345\256\232\345\200\237\351\230\205", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class UserBorrowWid: public Ui_UserBorrowWid {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERBORROWWID_H
