/********************************************************************************
** Form generated from reading UI file 'userbrowsewid.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERBROWSEWID_H
#define UI_USERBROWSEWID_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserBrowseWid
{
public:
    QLabel *label;
    QComboBox *comboBox;
    QPushButton *reushouye_button;
    QPushButton *seekbor_button;
    QTableWidget *tableWidget;

    void setupUi(QWidget *UserBrowseWid)
    {
        if (UserBrowseWid->objectName().isEmpty())
            UserBrowseWid->setObjectName(QStringLiteral("UserBrowseWid"));
        UserBrowseWid->resize(1335, 825);
        QFont font;
        font.setPointSize(14);
        UserBrowseWid->setFont(font);
        label = new QLabel(UserBrowseWid);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(330, 10, 121, 71));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setAutoFillBackground(true);
        comboBox = new QComboBox(UserBrowseWid);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(0, 70, 141, 41));
        reushouye_button = new QPushButton(UserBrowseWid);
        reushouye_button->setObjectName(QStringLiteral("reushouye_button"));
        reushouye_button->setGeometry(QRect(970, 60, 111, 51));
        reushouye_button->setAutoFillBackground(true);
        seekbor_button = new QPushButton(UserBrowseWid);
        seekbor_button->setObjectName(QStringLiteral("seekbor_button"));
        seekbor_button->setGeometry(QRect(960, 570, 161, 71));
        seekbor_button->setAutoFillBackground(true);
        tableWidget = new QTableWidget(UserBrowseWid);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(220, 130, 791, 401));
        QFont font2;
        font2.setPointSize(9);
        tableWidget->setFont(font2);

        retranslateUi(UserBrowseWid);

        QMetaObject::connectSlotsByName(UserBrowseWid);
    } // setupUi

    void retranslateUi(QWidget *UserBrowseWid)
    {
        UserBrowseWid->setWindowTitle(QApplication::translate("UserBrowseWid", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("UserBrowseWid", "\345\210\206\347\261\273\346\265\217\350\247\210", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("UserBrowseWid", "\347\254\2541\347\261\273", Q_NULLPTR)
         << QApplication::translate("UserBrowseWid", "\347\254\2542\347\261\273", Q_NULLPTR)
         << QApplication::translate("UserBrowseWid", "\347\254\2543\347\261\273", Q_NULLPTR)
        );
        reushouye_button->setText(QApplication::translate("UserBrowseWid", "\351\246\226\351\241\265", Q_NULLPTR));
        seekbor_button->setText(QApplication::translate("UserBrowseWid", "\345\200\237\351\230\205\344\271\246\347\261\215", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("UserBrowseWid", "ID", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("UserBrowseWid", "ISBN", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("UserBrowseWid", "\344\275\234\350\200\205", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("UserBrowseWid", "\344\271\246\345\220\215", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("UserBrowseWid", "\347\261\273\345\236\213", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("UserBrowseWid", "\345\234\250\346\236\266\344\277\241\346\201\257", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class UserBrowseWid: public Ui_UserBrowseWid {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERBROWSEWID_H
