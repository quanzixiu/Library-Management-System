/********************************************************************************
** Form generated from reading UI file 'userseekmw.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERSEEKMW_H
#define UI_USERSEEKMW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserSeekMw
{
public:
    QWidget *centralwidget;
    QGroupBox *menuseek_groupbox;
    QPushButton *idseek_button;
    QPushButton *isbnseek_button;
    QPushButton *nameseek_button;
    QPushButton *pushButton_4;
    QPushButton *bookcard_button;
    QPushButton *usershouye_button;
    QGroupBox *groupBox;
    QLineEdit *id_linedit;
    QPushButton *seekok_button;
    QPushButton *borrowok_button;
    QTableWidget *infobook_tablewid;
    QLabel *label;
    QPushButton *return_button;
    QMenuBar *menubar;
    QMenu *menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *UserSeekMw)
    {
        if (UserSeekMw->objectName().isEmpty())
            UserSeekMw->setObjectName(QStringLiteral("UserSeekMw"));
        UserSeekMw->resize(1226, 894);
        QFont font;
        font.setPointSize(10);
        UserSeekMw->setFont(font);
        centralwidget = new QWidget(UserSeekMw);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        menuseek_groupbox = new QGroupBox(centralwidget);
        menuseek_groupbox->setObjectName(QStringLiteral("menuseek_groupbox"));
        menuseek_groupbox->setGeometry(QRect(0, 150, 131, 241));
        menuseek_groupbox->setFont(font);
        idseek_button = new QPushButton(menuseek_groupbox);
        idseek_button->setObjectName(QStringLiteral("idseek_button"));
        idseek_button->setGeometry(QRect(0, 30, 101, 41));
        isbnseek_button = new QPushButton(menuseek_groupbox);
        isbnseek_button->setObjectName(QStringLiteral("isbnseek_button"));
        isbnseek_button->setGeometry(QRect(0, 70, 101, 41));
        nameseek_button = new QPushButton(menuseek_groupbox);
        nameseek_button->setObjectName(QStringLiteral("nameseek_button"));
        nameseek_button->setGeometry(QRect(0, 110, 101, 41));
        pushButton_4 = new QPushButton(menuseek_groupbox);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(0, 150, 101, 41));
        bookcard_button = new QPushButton(menuseek_groupbox);
        bookcard_button->setObjectName(QStringLiteral("bookcard_button"));
        bookcard_button->setGeometry(QRect(0, 190, 101, 41));
        usershouye_button = new QPushButton(centralwidget);
        usershouye_button->setObjectName(QStringLiteral("usershouye_button"));
        usershouye_button->setGeometry(QRect(820, 70, 111, 51));
        QFont font1;
        font1.setPointSize(14);
        usershouye_button->setFont(font1);
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(250, 140, 811, 561));
        id_linedit = new QLineEdit(groupBox);
        id_linedit->setObjectName(QStringLiteral("id_linedit"));
        id_linedit->setGeometry(QRect(60, 30, 113, 20));
        seekok_button = new QPushButton(groupBox);
        seekok_button->setObjectName(QStringLiteral("seekok_button"));
        seekok_button->setGeometry(QRect(220, 20, 51, 31));
        borrowok_button = new QPushButton(groupBox);
        borrowok_button->setObjectName(QStringLiteral("borrowok_button"));
        borrowok_button->setGeometry(QRect(690, 470, 101, 61));
        borrowok_button->setFont(font1);
        infobook_tablewid = new QTableWidget(groupBox);
        if (infobook_tablewid->columnCount() < 6)
            infobook_tablewid->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        infobook_tablewid->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        infobook_tablewid->setObjectName(QStringLiteral("infobook_tablewid"));
        infobook_tablewid->setGeometry(QRect(0, 140, 811, 301));
        infobook_tablewid->horizontalHeader()->setStretchLastSection(true);
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(370, 10, 201, 71));
        QFont font2;
        font2.setPointSize(15);
        font2.setBold(true);
        font2.setWeight(75);
        label->setFont(font2);
        label->setAutoFillBackground(true);
        return_button = new QPushButton(centralwidget);
        return_button->setObjectName(QStringLiteral("return_button"));
        return_button->setGeometry(QRect(1010, 750, 161, 71));
        return_button->setFont(font1);
        UserSeekMw->setCentralWidget(centralwidget);
        menubar = new QMenuBar(UserSeekMw);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1226, 17));
        menu = new QMenu(menubar);
        menu->setObjectName(QStringLiteral("menu"));
        UserSeekMw->setMenuBar(menubar);
        statusbar = new QStatusBar(UserSeekMw);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        UserSeekMw->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());

        retranslateUi(UserSeekMw);

        QMetaObject::connectSlotsByName(UserSeekMw);
    } // setupUi

    void retranslateUi(QMainWindow *UserSeekMw)
    {
        UserSeekMw->setWindowTitle(QApplication::translate("UserSeekMw", "MainWindow", Q_NULLPTR));
        menuseek_groupbox->setTitle(QApplication::translate("UserSeekMw", "\344\276\247\350\276\271\350\217\234\345\215\225\346\240\217", Q_NULLPTR));
        idseek_button->setText(QApplication::translate("UserSeekMw", "ID\346\237\245\346\211\276", Q_NULLPTR));
        isbnseek_button->setText(QApplication::translate("UserSeekMw", "ISBN\346\237\245\346\211\276", Q_NULLPTR));
        nameseek_button->setText(QApplication::translate("UserSeekMw", "\344\271\246\345\220\215\346\237\245\346\211\276", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("UserSeekMw", "\345\210\206\347\261\273\346\265\217\350\247\210", Q_NULLPTR));
        bookcard_button->setText(QApplication::translate("UserSeekMw", "\345\200\237\344\271\246\345\215\241", Q_NULLPTR));
        usershouye_button->setText(QApplication::translate("UserSeekMw", "\351\246\226\351\241\265", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("UserSeekMw", "\350\257\267\345\205\210\351\200\211\346\213\251\346\237\245\346\211\276\346\226\271\345\274\217\357\274\214\345\234\250\344\270\213\346\226\271\350\276\223\345\205\245ID(\350\207\263\345\244\232\344\270\2726\344\275\215)\346\210\226ISBN(\350\207\263\345\244\232\344\270\2726\344\275\215)\346\210\226\344\271\246\345\220\215(\350\207\263\345\244\232\344\270\2728\344\275\215)", Q_NULLPTR));
        seekok_button->setText(QApplication::translate("UserSeekMw", "\347\241\256\345\256\232", Q_NULLPTR));
        borrowok_button->setText(QApplication::translate("UserSeekMw", "\345\200\237\351\230\205", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = infobook_tablewid->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("UserSeekMw", "ID", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = infobook_tablewid->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("UserSeekMw", "\344\271\246\345\220\215", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = infobook_tablewid->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("UserSeekMw", "ISBN", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = infobook_tablewid->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("UserSeekMw", "\345\234\250\346\236\266\344\277\241\346\201\257", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = infobook_tablewid->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("UserSeekMw", "\344\275\234\350\200\205", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = infobook_tablewid->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("UserSeekMw", "\347\261\273\345\236\213", Q_NULLPTR));
        label->setText(QApplication::translate("UserSeekMw", "\346\237\245\346\211\276\345\200\237\351\230\205\345\233\276\344\271\246", Q_NULLPTR));
        return_button->setText(QApplication::translate("UserSeekMw", "\351\200\200\345\207\272\347\231\273\345\275\225", Q_NULLPTR));
        menu->setTitle(QApplication::translate("UserSeekMw", "\346\237\245\346\211\276\345\200\237\351\230\205\345\233\276\344\271\246", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class UserSeekMw: public Ui_UserSeekMw {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERSEEKMW_H
