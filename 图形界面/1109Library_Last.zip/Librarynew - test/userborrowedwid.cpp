#include "userborrowedwid.h"
#include "ui_userborrowedwid.h"

#include "o11userwid.h"
#include "objuserlogin.h"
#include "otwochoose.h"//不同系统选择界面

#include "borrow.h"
#include "global.h"//全局变量test
UserBorrowedWid::UserBorrowedWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserBorrowedWid)
{
    ui->setupUi(this);
    ui->stuid_linedit->setPlaceholderText("请输入整数形式的用户ID");//设置编辑框隐藏提示
    ui->stuid_linedit->setMaxLength(6);//设置输入位数限制
    ui->stuid_linedit->clear();
    QIntValidator *intValidator = new QIntValidator;
    this->ui->stuid_linedit->setValidator(intValidator);
    ui->borrowed_table->clearContents();//清空表格内容
    ui->borrowed_table->setRowCount(0);//1106test
    ui->borrowed_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //1106test设置表格内容用户不允许修改
}

UserBorrowedWid::~UserBorrowedWid()
{
    delete ui;
}
/*初始化界面
void UserBorrowedWid::Init()
{
//QString student11_id=ObjuserLogin::p_userlogin->GetId();
    LoginOneWid *plogin=new LoginOneWid();
    QString student11_id=plogin->GetId();
//QString student11_password=ObjuserLogin::p_userlogin->GetPassword();
    int id=student11_id.toInt();
//根据学生id查找所借书籍函数待填，共需所有书籍的返回信息
borrow br;
tuple <int,int *> t=br.qtrebookbor(id,Global::usd);
int count=get<0>(t);
if(count==0)
{
    QMessageBox::information(this,"提示","您还没有借阅过书籍");
}
else
{
    int *p=get<1>(t);//返回的是书籍id
    for(int i=0;i<count;i++)
    {   //int bid=p[i];
      book borrowedbooks;
      //返回book对象，显示对应信息函数
      borrowedbooks=br.qtidsearchbook(p[i],Global::bd);
    //需要将整型转换为Qstring型才可以显示
      int idint=borrowedbooks.getid();
      qDebug()<<idint;//test
      QString bookid;
    //bookid=bookid.setNum(idint);
      bookid=QString::number(idint);//10表示进制
      qDebug()<<bookid;//test
      int row=this->ui->borrowed_table->rowCount();
      this->ui->borrowed_table->insertRow(row);
      this->ui->borrowed_table->setItem(row,0,new QTableWidgetItem(bookid));
      this->ui->borrowed_table->setItem(row,1,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getname())));
      this->ui->borrowed_table->setItem(row,2,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getISBN())));
      this->ui->borrowed_table->setItem(row,3,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getauthor())));
      this->ui->borrowed_table->setItem(row,4,new QTableWidgetItem(QString::fromStdString( borrowedbooks.gettype())));
      this->ui->borrowed_table->setItem(row,5,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getborrowtime())));
      this->ui->borrowed_table->setItem(row,6,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getreturntime())));
    }
    delete []p;
}
QString id="12";
QString isbn="45";
QString writer="78";
QString bookname="810";
QString type="91";
int row=this->ui->borrowed_table->rowCount();
this->ui->borrowed_table->insertRow(row);
this->ui->borrowed_table->insertRow(row);
this->ui->borrowed_table->setItem(row,0,new QTableWidgetItem(id));
this->ui->borrowed_table->setItem(row,1,new QTableWidgetItem(isbn));
this->ui->borrowed_table->setItem(row,2,new QTableWidgetItem(writer));
this->ui->borrowed_table->setItem(row,3,new QTableWidgetItem(bookname));
this->ui->borrowed_table->setItem(row,4,new QTableWidgetItem(type));*/

//用户首页按钮
void UserBorrowedWid::on_shouye_button_clicked()
{
    ui->borrowed_table->clearContents();
    ui->stuid_linedit->clear();
    ui->borrowed_table->setRowCount(0);//1106test
    this->close();
    O11userwid::p_obj11->show();
}
//退出登录按钮：返回不同系统选择界面
void UserBorrowedWid::on_return_button_clicked()
{
    ui->borrowed_table->clearContents();
    ui->stuid_linedit->clear();
    ui->borrowed_table->setRowCount(0);//1106test
    this->close();
    Global::p.islogin=false;
    Otwochoose::p_otwochoose->show();
}
//id确定按钮
void UserBorrowedWid::on_useridok_button_clicked()
{
    this->ui->borrowed_table->clearContents();//1108test清空表格内容
    this->ui->borrowed_table->setRowCount(0);//1108test表格数初始
    int userid=ui->stuid_linedit->text().toInt();
    borrow br;
    bool flag=true;
    if(flag)
    {
        tuple <int,int *> t=br.qtrebookbor(userid,Global::usd);
        int count=get<0>(t);
        if(count==0)
        {
            QMessageBox::information(this,"提示","已借书籍数量为0");
        }
        else
        {
            int *p=get<1>(t);//返回的是书籍id
            for(int i=0;i<count;i++)
            {
              book borrowedbooks;
              //返回book对象，显示对应信息函数
              borrowedbooks=br.qtidsearchbook(p[i],Global::bd);
            //需要将整型转换为Qstring型才可以显示
              int idint=borrowedbooks.getid();
              qDebug()<<"已借书籍获取图书id"<<idint;//test
              QString bookid;
              bookid=QString::number(idint);//10表示进制
              //qDebug()<<bookid;test
              int row=this->ui->borrowed_table->rowCount();
              this->ui->borrowed_table->insertRow(row);
              this->ui->borrowed_table->setItem(row,0,new QTableWidgetItem(bookid));
              this->ui->borrowed_table->setItem(row,1,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getname())));
              this->ui->borrowed_table->setItem(row,2,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getISBN())));
              this->ui->borrowed_table->setItem(row,3,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getauthor())));
              this->ui->borrowed_table->setItem(row,4,new QTableWidgetItem(QString::fromStdString( borrowedbooks.gettype())));
              this->ui->borrowed_table->setItem(row,5,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getborrowtime())));
              this->ui->borrowed_table->setItem(row,6,new QTableWidgetItem(QString::fromStdString( borrowedbooks.getreturntime())));
            }//for
            ui->stuid_linedit->clear();
            delete []p;
          }//else
    }//if
    else
    {
        QMessageBox::information(this,"提示","您输入的id有误，请重新输入");
        ui->stuid_linedit->clear();
        ui->stuid_linedit->setFocus();
    }
}
