#include "userborrowwid.h"
#include "ui_userborrowwid.h"
#include "loginonewid.h"
#include "ouserseek.h"

#include "global.h"//全局变量
UserBorrowWid::UserBorrowWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserBorrowWid)
{
    ui->setupUi(this);
    ui->lineEdit->setMaxLength(6);
    ui->lineEdit->setPlaceholderText("图书ID");
    QIntValidator *intValidator = new QIntValidator;
    this->ui->lineEdit->setValidator(intValidator);
}

UserBorrowWid::~UserBorrowWid()
{
    delete ui;
}
//退出登录按钮
void UserBorrowWid::on_pushButton_2_clicked()
{
    this->close();
    LoginOneWid *p_loginuser=new LoginOneWid();
    p_loginuser->show();
}
//查找借阅按钮
void UserBorrowWid::on_seek_button_clicked()
{
    this->close();
    OuserSeek::p_oseek->show();
}
//输入确定按钮
void UserBorrowWid::on_inok_button_clicked()
{
    //查找图书是否存在待填
    int id=ui->lineEdit->text().toInt();
    bool falge=false;
    falge=Global:: p.qtbookexist(id,Global::bd);
    if(falge)
    {
        QMessageBox::information(this,"提示","该图书在架，可借阅");
    }
    else
    {
        QMessageBox::warning(this,"警告","您输入图书ID有误，请重新输入");
    }
}
//确定借阅按钮
void UserBorrowWid::on_borrowok_button_clicked()
{
    //借阅图书函数待填
    QMessageBox::information(this,"提示","借书成功");
    QMessageBox::information(this,"提示","借书失败");
}
