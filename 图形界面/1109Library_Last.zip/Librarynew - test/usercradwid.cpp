#include "usercradwid.h"
#include "ui_usercradwid.h"

#include "ouserseek.h"

#include "borrow.h"
#include "global.h"//全局变量test
UserCradWid::UserCradWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserCradWid)
{
    ui->setupUi(this);
    ui->lineEdit->clear();
    ui->lineEdit->setPlaceholderText("请输入整数形式的图书ID");
    ui->lineEdit->setMaxLength(6);
    ui->card_table->clearContents();//1107test
    QIntValidator *intValidator = new QIntValidator;
    this->ui->lineEdit->setValidator(intValidator);
}

UserCradWid::~UserCradWid()
{
    delete ui;
}
//返回查找借阅图书按钮
void UserCradWid::on_cardseek_button_clicked()
{
    ui->card_table->clearContents();//1107test
    this->close();
    OuserSeek::p_oseek->show();
}
//确定显示已借该书的读者信息
void UserCradWid::on_cardok_button_clicked()
{
    this->ui->card_table->clearContents();//1108test清空表格内容
    this->ui->card_table->setRowCount(0);//1108test表格从1开始
    int bookid=ui->lineEdit ->text().toInt();
    borrow p;
    bool flag=false;
    flag=p.qtbookexist(bookid,Global::bd);//判断该图书id是否存在函数
    if(flag)
    {
        //根据图书id查找借阅该书的学生id函数
        tuple<int,int*> card=p.qtreusercard(bookid,Global::bd);
        int count=get<0>(card);
        if(count==0)
        {
            QMessageBox::information(this,"提示","当前图书没有借书卡记录");
            ui->lineEdit->clear();
        }
        else
        {
           int *p_user=get<1>(card);
           for(int i=0;i<count;i++)
           {
            int id=p_user[i];
            user stu=Global::p.qtidsearchuser(id,Global::ud);//1108test获取用户对象
            //将int型id转换为Qstring型
            QString userid,temp;
            userid=temp.setNum(id);
            //QString::number(id,10);
            int row=this->ui->card_table->rowCount();
            this->ui->card_table->insertRow(row);
            this->ui->card_table->setItem(row,0,new QTableWidgetItem(userid));
            this->ui->card_table->setItem(row,1,new QTableWidgetItem(QString::fromStdString(stu.getname())));
            this->ui->card_table->setItem(row,2,new QTableWidgetItem(QString::fromStdString(stu.getcollege())));
            this->ui->card_table->setItem(row,3,new QTableWidgetItem(QString::fromStdString(stu.getmajor())));
            this->ui->card_table->setItem(row,4,new QTableWidgetItem(QString::fromStdString(stu.getemail())));
            }
            delete []p_user;
            ui->lineEdit->clear();
         }
    }
    else
    {
         QMessageBox::information(this,"提示","您输入的图书id有错误，请重新输入");
          ui->lineEdit->clear();
          ui->lineEdit->setFocus();//1107test
    }
}


