#include "userdelete.h"
#include "ui_userdelete.h"
//int idnum;
UserDelete::UserDelete(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserDelete)
{

    ui->setupUi(this);
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("GB2312"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    this->ui->le_id->setMaxLength(8);
    QIntValidator *intValidator = new QIntValidator;
    this->ui->le_id->setValidator(intValidator);
}

UserDelete::~UserDelete()
{
    delete ui;
}
void UserDelete::on_gotomainpage_clicked()
{
    this->close();
    MainPage* mp = new MainPage();
    mp->show();
}
void UserDelete::on_exitlogin_clicked()
{
    this->close();
    OneWelcomeW* oww=new OneWelcomeW();
    oww->show();
}
void UserDelete::on_confirmsure_clicked()
{
    QString id=this->ui->le_id->text();

    //this->ui->le_id->setMaxLength(8);
    int idnum=id.toInt();
    //qDebug()<<idnum;
    //userdocking ud;
    //userstatesdocking usd;
    bool flag=Global::ud.userdelete(idnum);
    qDebug()<<flag;
    if (flag){
        supervisor s;
        //string str=s.DisplayUserBookid(Global::ud,Global::usd,idnum);
        //QString disstr=QString::fromStdString(str);
        //this->ui->borrowinfotable->setPlainText(disstr);

        bool sure=s.deleteuser(Global::ud,Global::usd,idnum);
        QMessageBox::information(this,"提示","删除用户成功");
        //qDebug()<<sure;
        if(sure){

            this->ui->le_id->clear();
            //this->ui->borrowinfotable->clear();
        }
        else{
            QMessageBox::information(this,"提示","删除用户失败");
        }

    }
    else{
        QMessageBox::information(this,"提示","删除用户失败");
        this->ui->le_id->clear();
        //this->ui->borrowinfotable->clear();
    }
}
void UserDelete::on_addusers_clicked()
{
    this->close();
    UserManager* um = new UserManager();
    um->show();
}
void UserDelete::on_updateusers_clicked()
{
    this->close();
    UserUpdate* uu = new UserUpdate();
    uu->show();
}
void UserDelete::on_deleteusers_clicked()
{
    this->close();
    UserDelete* ud = new UserDelete();
    ud->show();
}
