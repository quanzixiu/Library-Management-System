#include "userdocking.h"

userdocking::userdocking(){}



bool userdocking::useradd(int id, string name, string college, string major, string password, string email)
{
    value = name + college + major + password + email;
    if (userdatabase.insert(id, value))
    return true;
    else
    return false;
}
bool userdocking::userdelete(int id) {
    if (userdatabase.remove(id))
    return true;
    else
    return false;
}

string userdocking::usersearch(int id) {
    if (userdatabase.select(id, value))
    {
        value = value.substr(0, 56);
        return value;
    }
}

bool userdocking::userexist(int id) {
    if (userdatabase.select(id, value))
        return true;
    else
        return false;
}
bool userdocking::usermodifyname(int id, string name) {
    if (userdatabase.select(id, value)) {
        value = value.substr(0, 56);
        string s1, s2;
        s1 = value.substr(8, 48);
        name = name.append(8 - name.size(), ' ');
        value = name + s1;
        if (userdatabase.update(id, value))
            return true;
        else
            return false;
    }
    else
        return false;
}
bool userdocking::usermodifycollege(int id, string college) {
    if (userdatabase.select(id, value)){
        value = value.substr(0, 56);
        string s1, s2;
        s1 = value.substr(0, 8);
        s2 = value.substr(12, 44);
        college = college.append(4 - college.size(), ' ');
        value = s1 + college + s2;
        if (userdatabase.update(id, value))
            return true;
        else
            return false;
    }
    else
        return false;
}
bool userdocking::usermodifymajor(int id, string major) {
    if (userdatabase.select(id, value)){
        value = value.substr(0, 56);
        string s1, s2;
        s1 = value.substr(0, 12);
        s2 = value.substr(16, 40);
        major = major.append(4 - major.size(), ' ');
        value = s1 + major + s2;
        if (userdatabase.update(id, value))
            return true;
        else
            return false;
    }
    else
        return false;
}
bool userdocking::usermodifypassword(int id, string password) {
    if (userdatabase.select(id, value)){
        value = value.substr(0, 56);
        string s1, s2;
        s1 = value.substr(0, 16);
        s2 = value.substr(32, 24);
        password = password.append(16 - password.size(), ' ');
        value = s1 + password + s2;
        if (userdatabase.update(id, value))
            return true;
        else
            return false;
    }
    else
        return false;
}
bool userdocking::usermodifyemail(int id, string email) {
    if (userdatabase.select(id, value)){
        value = value.substr(0, 56);
        string s1, s2;
        s1 = value.substr(0, 32);

        email = email.append(24 - email.size(), ' ');
        value = s1 + email;
        if (userdatabase.update(id, value))
            return true;
        else
            return false;
    }
    else
        return false;
}





