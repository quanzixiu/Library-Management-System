#include "userreturnwid.h"
#include "ui_userreturnwid.h"

#include "twochoosewid.h"
#include "objuserlogin.h"

#include "global.h"//全局变量test
#include "returnbook.h" //逻辑层还书头文件
#include "borrow.h"//图书id查找函数
UserReturnWid::UserReturnWid(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserReturnWid)
{
    ui->setupUi(this);
    ui->lineEdit->clear();
    ui->lineEdit->setPlaceholderText("请输入整数形式的图书ID");
    ui->lineEdit->setMaxLength(6);//输入位数限制
    QIntValidator *intValidator = new QIntValidator;
    this->ui->lineEdit->setValidator(intValidator);
}

UserReturnWid::~UserReturnWid()
{
    delete ui;
}
//查找借阅按钮：返回登录界面，登录才能借阅
void UserReturnWid::on_seekbor_button_clicked()
{
    ui->lineEdit->clear();
    this->close();
    ObjuserLogin::p_userlogin->show();
}
//退出按钮:返回“管理员系统借阅系统还书系统”选择界面
void UserReturnWid::on_return_button_clicked()
{
    ui->lineEdit->clear();
    this->close();
    TwoChooseWid *p=new TwoChooseWid();
    p->show();
}
//确定按钮:显示图书信息
void UserReturnWid::on_returnok_button_clicked()
{   
   int book_id=ui->lineEdit->text().toInt();
   qDebug()<<"还书获取图书ID"<<book_id;
   //书籍查找函数
   borrow idsearch;
   bool falge=idsearch.qtbookexist(book_id,Global::bd);
   qDebug()<<"归还按钮判断"<<falge;
   if(falge)//查找正确显示图书信息
   {
       book newbook=idsearch.qtidsearchbook(book_id,Global::bd);//书籍信息返回函数
       QString id=ui->lineEdit->text();
       QString bookname=QString::fromStdString(newbook.getname());
       QString isbn=QString::fromStdString(newbook.getISBN());
       QString writer=QString::fromStdString(newbook.getauthor());
       QString type=QString::fromStdString(newbook.gettype());
       QString borrowtime=QString::fromStdString(newbook.getborrowtime());
       QString returntime=QString::fromStdString(newbook.getreturntime());
       int row=this->ui->returninfo_table->rowCount();
       this->ui->returninfo_table->insertRow(row);
       this->ui->returninfo_table->setItem(row,0,new QTableWidgetItem(id));
       this->ui->returninfo_table->setItem(row,1,new QTableWidgetItem(bookname));
       this->ui->returninfo_table->setItem(row,2,new QTableWidgetItem(isbn));
       this->ui->returninfo_table->setItem(row,3,new QTableWidgetItem(writer));
       this->ui->returninfo_table->setItem(row,4,new QTableWidgetItem(type));
       this->ui->returninfo_table->setItem(row,5,new QTableWidgetItem(borrowtime));
       this->ui->returninfo_table->setItem(row,6,new QTableWidgetItem(returntime));
   }
   else
   {
       QMessageBox::information(this,"提示","您输入的信息有误，请重新输入");
       ui->lineEdit->clear();
       ui->lineEdit->setFocus();
   }

}
//归还图书按钮
void UserReturnWid::on_returnbook_button_clicked()
{
    //归还图书函数
    int book_id=ui->lineEdit->text().toInt();
    returnbook oreturn;
    bool flag=oreturn.returnBook(Global::bd,Global::usd,book_id);
    if(flag)
    {
        QMessageBox::information(this,"提示","归还成功");
    }
    else
    {
        QMessageBox::warning(this,"警告","您归还图书出现错误，请联系管理员");
    }
    ui->lineEdit->clear();
}
