#include "userseekmw.h"
#include "ui_userseekmw.h"

#include "o11userwid.h"
#include "otwochoose.h"

#include "userbrowsewid.h"//分类浏览
#include "obookcard.h"
#include "userborrowwid.h"//借阅书籍

#include "global.h"//全局变量test
//#include "borrow.h"已包含引用book和user的头文件

UserSeekMw::UserSeekMw(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UserSeekMw)
{
    ui->setupUi(this);
    ui->id_linedit->setMaxLength(6);
    ui->id_linedit->clear();//清空编辑框
    ui->infobook_tablewid->clearContents();//清空表格内容1106test
    ui->infobook_tablewid->setRowCount(0);//1106test
    ui->infobook_tablewid->setEditTriggers(QAbstractItemView::NoEditTriggers);
    //1106test表格内容不允许用户修改
}

UserSeekMw::~UserSeekMw()
{
    delete ui;
}
//首页按钮
void UserSeekMw::on_usershouye_button_clicked()
{
    ui->id_linedit->clear();//清空编辑框
    ui->infobook_tablewid->clearContents();//清空表格内容
    ui->infobook_tablewid->setRowCount(0);//1106test
    this->close();
    O11userwid::p_obj11->show();   
}
//退出登录按钮：返回不同系统选择界面
void UserSeekMw::on_return_button_clicked()
{
    ui->id_linedit->clear();//清空编辑框
    ui->infobook_tablewid->clearContents();//清空表格内容
    ui->infobook_tablewid->setRowCount(0);//1106test
    Global::p.islogin=false;
    this->close();
    Otwochoose::p_otwochoose->show();
}
//借书卡按钮
void UserSeekMw::on_bookcard_button_clicked()
{
    ui->id_linedit->clear();//清空编辑框
    ui->infobook_tablewid->clearContents();//清空表格内容
    ui->infobook_tablewid->setRowCount(0);//1106test
    this->close();
    ObookCard::p_objcard->show();    
}
//由ID查找
void UserSeekMw::searchbyid()
{
    //显示图书函数logical
    int id = ui->id_linedit->text().toInt();
    book seekbook = Global::p.qtidsearchbook(id, Global::bd);
    //表格
    QString bid = ui->id_linedit->text();
    QString bookname = QString::fromStdString(seekbook.getname());
    QString isbn = QString::fromStdString(seekbook.getISBN());
    QString onself = QString::fromStdString(seekbook.getonsheelf());
    QString writer = QString::fromStdString(seekbook.getauthor());
    QString type = QString::fromStdString(seekbook.gettype());
    int row = this->ui->infobook_tablewid->rowCount();
    this->ui->infobook_tablewid->insertRow(row);
    this->ui->infobook_tablewid->setItem(row, 0, new QTableWidgetItem(bid));
    this->ui->infobook_tablewid->setItem(row, 1, new QTableWidgetItem(bookname));
    this->ui->infobook_tablewid->setItem(row, 2, new QTableWidgetItem(isbn));
    this->ui->infobook_tablewid->setItem(row, 3, new QTableWidgetItem(onself));
    this->ui->infobook_tablewid->setItem(row, 4, new QTableWidgetItem(writer));
    this->ui->infobook_tablewid->setItem(row, 5, new QTableWidgetItem(type));
}
//由ISBN查找
void UserSeekMw::searchbyisbn()
{
    //显示图书函数logical
    int id = ui->id_linedit->text().toInt();
    book seekbook = Global::p.qtidsearchbook(id, Global::bd);

    //表格
    QString bid = ui->id_linedit->text();
    QString bookname = QString::fromStdString(seekbook.getname());
    QString isbn = QString::fromStdString(seekbook.getISBN());
    QString onself = QString::fromStdString(seekbook.getonsheelf());
    QString writer = QString::fromStdString(seekbook.getauthor());
    QString type = QString::fromStdString(seekbook.gettype());
    int row = this->ui->infobook_tablewid->rowCount();
    this->ui->infobook_tablewid->insertRow(row);
    this->ui->infobook_tablewid->setItem(row, 0, new QTableWidgetItem(bid));
    this->ui->infobook_tablewid->setItem(row, 1, new QTableWidgetItem(bookname));
    this->ui->infobook_tablewid->setItem(row, 2, new QTableWidgetItem(isbn));
    this->ui->infobook_tablewid->setItem(row, 3, new QTableWidgetItem(onself));
    this->ui->infobook_tablewid->setItem(row, 4, new QTableWidgetItem(writer));
    this->ui->infobook_tablewid->setItem(row, 5, new QTableWidgetItem(type));
}
//由书名查找
void UserSeekMw::searchbyname()
{
    //显示图书函数logical
    int id = ui->id_linedit->text().toInt();
    book seekbook = Global::p.qtidsearchbook(id, Global::bd);
    //表格
    QString bid = ui->id_linedit->text();
    QString bookname = QString::fromStdString(seekbook.getname());
    QString isbn = QString::fromStdString(seekbook.getISBN());
    QString onself = QString::fromStdString(seekbook.getonsheelf());
    QString writer = QString::fromStdString(seekbook.getauthor());
    QString type = QString::fromStdString(seekbook.gettype());
    int row = this->ui->infobook_tablewid->rowCount();
    this->ui->infobook_tablewid->insertRow(row);
    this->ui->infobook_tablewid->setItem(row, 0, new QTableWidgetItem(bid));
    this->ui->infobook_tablewid->setItem(row, 1, new QTableWidgetItem(bookname));
    this->ui->infobook_tablewid->setItem(row, 2, new QTableWidgetItem(isbn));
    this->ui->infobook_tablewid->setItem(row, 3, new QTableWidgetItem(onself));
    this->ui->infobook_tablewid->setItem(row, 4, new QTableWidgetItem(writer));
    this->ui->infobook_tablewid->setItem(row, 5, new QTableWidgetItem(type));
}

//查找确定
void UserSeekMw::on_seekok_button_clicked()
{
    int id = ui->id_linedit->text().toInt();
    //查找函数待填
    bool falge = false;
    falge = Global::p.qtbookexist(id, Global::bd);
    qDebug() << "borrowseekok" << falge;
    int c = this->getchoice();
    if (falge)
    {
        switch (c) {
        case 1:
            this->searchbyid();
            break;
        case 2:
            this->searchbyisbn();
            break;
        case 3:
            this->searchbyname();
            break;
        default:
            break;
        }
    }
    else
    {
        QMessageBox::warning(this, "警告", "您输入的id不在查找范围，请重新输入");
        ui->id_linedit->clear();
    }
}
//借阅按钮
void UserSeekMw::on_borrowok_button_clicked()
{
    int book_id=this->ui->id_linedit->text().toInt();
    qDebug()<<"借阅按钮获取ID"<<book_id;//test
    bool judge=Global::p.qtborrowbook(book_id,Global::bd,Global::usd);
    qDebug()<<"借阅按钮判断"<<judge;//test
    int rowborrow=this->ui->infobook_tablewid->rowCount();//1108test
    qDebug()<<"rewborrow"<<rowborrow;
    if(judge)//借书成功
    {
        QMessageBox::information(this,"提示","借书成功");        
        //this-ui->infobook_tablewid->clearContents();
    }
     else
     {
        QMessageBox::information(this,"提示","借书失败，请您检查是否超出借书上限或请联系管理员");
     }
    ui->id_linedit->clear();//借阅完书籍清空编辑框
}
//分类浏览按钮
void UserSeekMw::on_pushButton_4_clicked()
{
    this->close();
    UserBrowseWid *p_browse=new UserBrowseWid();
    p_browse->show();
    ui->id_linedit->clear();//1106test
    ui->infobook_tablewid->clearContents();//清空表格内容
    ui->infobook_tablewid->setRowCount(0);//1106test
}
//ID查找
void UserSeekMw::on_idseek_button_clicked()
{
    this->ui->id_linedit->setPlaceholderText("输入图书ID");
    this->setchoice(1);
    //QIntValidator *intValidator = new QIntValidator;
    //this->ui->id_linedit->setValidator(intValidator);
}
//ISBN查找
void UserSeekMw::on_isbnseek_button_clicked()
{
    this->ui->id_linedit->setPlaceholderText("输入图书ISBN");
    this->setchoice(2);
}
//名字查找
void UserSeekMw::on_nameseek_button_clicked()
{
    this->ui->id_linedit->setPlaceholderText("输入图书名字");
    this->setchoice(3);
}
