#ifndef USERSEEKMW_H
#define USERSEEKMW_H

#include <QMainWindow>
#include <QMessageBox>
//限制输入控件输入位数
#include <QValidator>
#include <QRegExp>
#include <QRegExpValidator>
#include <QDebug>

namespace Ui {
class UserSeekMw;
}

class UserSeekMw : public QMainWindow
{
    Q_OBJECT

public:
    explicit UserSeekMw(QWidget *parent = 0);
    ~UserSeekMw();
    int getchoice() { return choice; }
    void setchoice(int c) { choice = c; }
    void searchbyid();
    void searchbyisbn();
    void searchbyname();
private slots:
    void on_usershouye_button_clicked();

    void on_return_button_clicked();

    void on_bookcard_button_clicked();

    void on_seekok_button_clicked();

    void on_borrowok_button_clicked();

    void on_pushButton_4_clicked();

    void on_idseek_button_clicked();

    void on_isbnseek_button_clicked();

    void on_nameseek_button_clicked();
private:
    Ui::UserSeekMw *ui;
    int choice; //1-3分对应侧边栏从上到下按钮
};

#endif // USERSEEKMW_H
