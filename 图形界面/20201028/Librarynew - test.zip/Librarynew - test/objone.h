#ifndef OBJONE_H
#define OBJONE_H
#include "onewelcomew.h"

class Objone
{
public:
    Objone();
    static OneWelcomeW *p_objone;
    static void Init();
};

#endif // OBJONE_H
