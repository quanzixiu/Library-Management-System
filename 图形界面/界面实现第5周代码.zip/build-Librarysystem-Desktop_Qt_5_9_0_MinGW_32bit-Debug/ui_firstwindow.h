/********************************************************************************
** Form generated from reading UI file 'firstwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIRSTWINDOW_H
#define UI_FIRSTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_firstwindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QPushButton *checkbutton;
    QLabel *label_2;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *firstwindow)
    {
        if (firstwindow->objectName().isEmpty())
            firstwindow->setObjectName(QStringLiteral("firstwindow"));
        firstwindow->resize(400, 300);
        centralWidget = new QWidget(firstwindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(70, 70, 301, 91));
        QFont font;
        font.setPointSize(15);
        label->setFont(font);
        label->setLayoutDirection(Qt::LeftToRight);
        label->setAutoFillBackground(true);
        checkbutton = new QPushButton(centralWidget);
        checkbutton->setObjectName(QStringLiteral("checkbutton"));
        checkbutton->setGeometry(QRect(130, 170, 21, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(160, 150, 151, 61));
        QFont font1;
        font1.setPointSize(9);
        label_2->setFont(font1);
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(120, 200, 81, 41));
        QFont font2;
        font2.setPointSize(13);
        pushButton->setFont(font2);
        firstwindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(firstwindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 17));
        firstwindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(firstwindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        firstwindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(firstwindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        firstwindow->setStatusBar(statusBar);

        retranslateUi(firstwindow);

        QMetaObject::connectSlotsByName(firstwindow);
    } // setupUi

    void retranslateUi(QMainWindow *firstwindow)
    {
        firstwindow->setWindowTitle(QApplication::translate("firstwindow", "firstwindow", Q_NULLPTR));
        label->setText(QApplication::translate("firstwindow", "\346\254\242\350\277\216\346\235\245\345\210\260\345\233\276\344\271\246\347\256\241\347\220\206\347\263\273\347\273\237\357\274\201", Q_NULLPTR));
        checkbutton->setText(QString());
        label_2->setText(QApplication::translate("firstwindow", "\345\220\214\346\204\217\344\275\277\347\224\250\345\215\217\350\256\256", Q_NULLPTR));
        pushButton->setText(QApplication::translate("firstwindow", "\350\277\233\345\205\245", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class firstwindow: public Ui_firstwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIRSTWINDOW_H
