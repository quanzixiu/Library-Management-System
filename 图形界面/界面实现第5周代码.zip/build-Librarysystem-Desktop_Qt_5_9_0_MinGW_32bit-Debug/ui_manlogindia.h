/********************************************************************************
** Form generated from reading UI file 'manlogindia.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANLOGINDIA_H
#define UI_MANLOGINDIA_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_manlogindia
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *manID;
    QLineEdit *manpassword;
    QPushButton *manloginbutton;
    QPushButton *exitbutton;

    void setupUi(QDialog *manlogindia)
    {
        if (manlogindia->objectName().isEmpty())
            manlogindia->setObjectName(QStringLiteral("manlogindia"));
        manlogindia->resize(400, 300);
        label = new QLabel(manlogindia);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(120, 50, 71, 31));
        QFont font;
        font.setPointSize(13);
        label->setFont(font);
        label_2 = new QLabel(manlogindia);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 100, 31, 21));
        QFont font1;
        font1.setPointSize(10);
        label_2->setFont(font1);
        label_3 = new QLabel(manlogindia);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 130, 51, 21));
        label_3->setFont(font1);
        manID = new QLineEdit(manlogindia);
        manID->setObjectName(QStringLiteral("manID"));
        manID->setGeometry(QRect(100, 100, 113, 20));
        manpassword = new QLineEdit(manlogindia);
        manpassword->setObjectName(QStringLiteral("manpassword"));
        manpassword->setGeometry(QRect(100, 130, 113, 20));
        manloginbutton = new QPushButton(manlogindia);
        manloginbutton->setObjectName(QStringLiteral("manloginbutton"));
        manloginbutton->setGeometry(QRect(140, 160, 41, 20));
        exitbutton = new QPushButton(manlogindia);
        exitbutton->setObjectName(QStringLiteral("exitbutton"));
        exitbutton->setGeometry(QRect(260, 200, 31, 21));

        retranslateUi(manlogindia);

        QMetaObject::connectSlotsByName(manlogindia);
    } // setupUi

    void retranslateUi(QDialog *manlogindia)
    {
        manlogindia->setWindowTitle(QApplication::translate("manlogindia", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("manlogindia", "\347\256\241\347\220\206\345\221\230\347\231\273\345\275\225", Q_NULLPTR));
        label_2->setText(QApplication::translate("manlogindia", "ID", Q_NULLPTR));
        label_3->setText(QApplication::translate("manlogindia", "password", Q_NULLPTR));
        manloginbutton->setText(QApplication::translate("manlogindia", "\347\231\273\345\275\225", Q_NULLPTR));
        exitbutton->setText(QApplication::translate("manlogindia", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class manlogindia: public Ui_manlogindia {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANLOGINDIA_H
