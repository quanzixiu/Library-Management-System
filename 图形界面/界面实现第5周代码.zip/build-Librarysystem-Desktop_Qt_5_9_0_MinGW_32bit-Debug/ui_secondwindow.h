/********************************************************************************
** Form generated from reading UI file 'secondwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SECONDWINDOW_H
#define UI_SECONDWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_secondwindow
{
public:
    QLabel *label;
    QPushButton *managerbutton;
    QPushButton *userbutton;
    QPushButton *twoexitbutton;

    void setupUi(QWidget *secondwindow)
    {
        if (secondwindow->objectName().isEmpty())
            secondwindow->setObjectName(QStringLiteral("secondwindow"));
        secondwindow->resize(400, 300);
        label = new QLabel(secondwindow);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 50, 281, 91));
        QFont font;
        font.setPointSize(13);
        label->setFont(font);
        label->setLayoutDirection(Qt::LeftToRight);
        label->setAutoFillBackground(true);
        managerbutton = new QPushButton(secondwindow);
        managerbutton->setObjectName(QStringLiteral("managerbutton"));
        managerbutton->setGeometry(QRect(120, 160, 101, 41));
        userbutton = new QPushButton(secondwindow);
        userbutton->setObjectName(QStringLiteral("userbutton"));
        userbutton->setGeometry(QRect(120, 210, 101, 41));
        twoexitbutton = new QPushButton(secondwindow);
        twoexitbutton->setObjectName(QStringLiteral("twoexitbutton"));
        twoexitbutton->setGeometry(QRect(250, 260, 41, 31));

        retranslateUi(secondwindow);

        QMetaObject::connectSlotsByName(secondwindow);
    } // setupUi

    void retranslateUi(QWidget *secondwindow)
    {
        secondwindow->setWindowTitle(QApplication::translate("secondwindow", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("secondwindow", "\350\257\267\351\200\211\346\213\251\346\202\250\351\234\200\350\246\201\347\232\204\347\263\273\347\273\237", Q_NULLPTR));
        managerbutton->setText(QApplication::translate("secondwindow", "\347\256\241\347\220\206\345\221\230\347\263\273\347\273\237", Q_NULLPTR));
        userbutton->setText(QApplication::translate("secondwindow", "\347\224\250\346\210\267\347\263\273\347\273\237", Q_NULLPTR));
        twoexitbutton->setText(QApplication::translate("secondwindow", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class secondwindow: public Ui_secondwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SECONDWINDOW_H
