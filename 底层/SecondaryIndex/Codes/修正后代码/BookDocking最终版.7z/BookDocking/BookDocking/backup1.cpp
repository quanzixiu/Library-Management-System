			/*
			fEmpty.seekp(0, ios::beg);
			getline(fEmpty, new_str);
			while (atoi(new_str.c_str()) != line_num) {
				firstEmpty = fEmpty.tellg();
				getline(fEmpty, new_str);
				}
			fEmpty.seekp(firstEmpty, ios::beg);
			fEmpty.write(zero_str.c_str(),LENGTH_INDEXADDRESS);
			*/
			Empty.clear();
			//v_index = to_string(p_index);//trans p_index to v_index
			Empty.seekg(/*secEmpty*/0, ios::beg);
			//getline(Empty, new_str);//escape the line 0
			secEmpty = Empty.tellg();
			getline(Empty, new_str);//start from the line 0
			//cir_time += 1;
			//secEmpty = Empty.tellg();
//			if (!atoi(new_str.c_str())) {//if gets 0, means that the first line is 00000000, but in secIndex there's a blank line there
//				goto SIG_1;
//			}
			//while new_str receives not "00000000" (0 in int), keep traversing for the next line,
			while (atoi(new_str.substr(0, LENGTH_INDEXADDRESS).c_str())) {
				//until find a "00000000" to rewrite into.
				//also, use new_str != "0000" to check.
			//while(new_str != "    "){//until find a "    " to rewrite into.

//				SIG_1:
				if (Empty.peek() == EOF /*&& cir_time == 1*/) {
					//Empty.clear();
					Empty.seekg(0, ios::end);
					//tmpPr = Empty.tellg();
					secEmpty = Empty.tellg();//skip the line 0
//					goto SIG_2;//skip the next read
				}
				secEmpty = Empty.tellg();
				getline(Empty, new_str);
				//cir_time += 1;
				//secEmpty = Empty.tellg();
			}//until find a "00000000" pos.
			
//			SIG_2://add directly
			//if (!atoi(new_str.c_str()))
			//if (Empty.tellg() == LENGTH_INDEXADDRESS + sizeof(char)) { ; }
