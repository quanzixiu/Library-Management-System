#include "userstatesdocking.h"

userstatesdocking::userstatesdocking(){}



bool userstatesdocking::uscreate(int id,string bookid)
{
	
	bookid = bookid.append(120 - bookid.size(), ' ');
	value = bookid;
	if (userstatesdatabase.insert(id, value))
	return true;
	else
	return false;

}

bool userstatesdocking::usadd(int id, string bookid) {
	if (userstatesdatabase.select(id, value)) {
		value = value.substr(0, 120);
		for (int i = 0; i < 20; i++) {
			if (value.substr(i * 6, 6).compare("      ")==0) {
				//value.replace(i * 6, 6, bookid);
				if (i==0) 
				{
					string s1, s2;
					s1 = value.substr(6, 114);
					bookid = bookid.append(6 - bookid.size(), ' ');
					value = bookid + s1;

				}
				else if (i==19) 
				{
					string s1, s2;
					s1 = value.substr(0, 114);
					bookid = bookid.append(6 - bookid.size(), ' ');
					value = s1+bookid;
				}
				else {
					string s1, s2;
					s1 = value.substr(0, i * 6);
					s2 = value.substr(i * 6 + 6, 120 - (i * 6 + 6));
					bookid = bookid.append(6 - bookid.size(), ' ');
					value = s1 + bookid + s2;

				}
				break;
			}
			
		}
		if (userstatesdatabase.update(id, value)) {
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

bool userstatesdocking::usdelete(int id,string bookid) {
	string str;
	bookid= bookid.append(6 - bookid.size(), ' ');
	if (userstatesdatabase.select(id, value))
	{
		for (int i = 0; i < 20; i++) {
			if (value.substr(i * 6, 6).compare(bookid)==0) {//循环判断已借书单中每本书的id是不是要删除的书的id
				str = value.substr(i * 6 + 6, 120 - (i * 6 + 6));  //截取这个id后的所有的字符串，在120个字符串以内的， 
				str = str + "      ";//str要整体往前移动6位，把要删除的id覆盖了，这样整个value就少了6位，在这里补上
				//以前我是截取了之后拼到value中的修改位置之后，之后再加6个空格，这样容易出错，现在改成截取完之后加6个空格在拼到value中的修改位置之后
				value.replace(i * 6, 120-(i*6), str);
				value = value.substr(0, 120);//以防万一再截取一边，防止把乱码加进来。
				break;	
			}
		}
		if (userstatesdatabase.update(id, value)) {
			return true;
		}
		else
			return false;
	}

	else
		return false;
}

string userstatesdocking::ussearch(int id) {
	if (userstatesdatabase.select(id, value))
	{
		value = value.substr(0, 120);
		return value;
	}
}

bool userstatesdocking::usexist(int id) {
	if (userstatesdatabase.select(id, value))
		return true;
	else
		return false;
}

bool userstatesdocking::usdeleteall(int id) {
	if (userstatesdatabase.remove(id))
		return true;
	else
		return false;
}

