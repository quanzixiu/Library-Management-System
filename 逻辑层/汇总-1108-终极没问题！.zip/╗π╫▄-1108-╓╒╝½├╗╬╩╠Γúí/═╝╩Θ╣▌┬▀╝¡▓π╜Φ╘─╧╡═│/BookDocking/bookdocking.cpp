#include "bookdocking.h"

bookdocking::bookdocking(){}

bool bookdocking::bookadd(int id,string ISBN, string name, string author, string type, string borrowtime, string returntime, string histroy, string onsheelf, string isovertime)
{
	value = ISBN + name + author + type + borrowtime + returntime + histroy + onsheelf + isovertime;
	if (bookdatabase.insert(id, value))
	return true;
	else
	return false;

}
bool bookdocking::bookdelete(int id) {
	if (bookdatabase.remove(id))
	return true;
	else
	return false;
}

string bookdocking::booksearch(int id) {
	if (bookdatabase.select(id, value))
	{
		value = value.substr(0, 80);
		return value;
	}
}

bool bookdocking::bookexist(int id) {
	if (bookdatabase.select(id, value))
		return true;
	else
		return false;
}
bool bookdocking::bookmodifyISBN(int id, string ISBN) {
	if (bookdatabase.select(id, value)) {
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(6, 80);
		ISBN=ISBN.append(6 - ISBN.size(), ' ');
		value=ISBN+s1;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyname(int id, string name) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 6);
		s2 = value.substr(14, 66);
		name = name.append(8 - name.size(), ' ');
		value = s1 + name + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyauthor(int id, string author) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 14);
		s2 = value.substr(18, 62);
		author = author.append(4 - author.size(), ' ');
		value = s1 + author + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifytype(int id, string type) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 18);
		s2 = value.substr(22, 58);
		type = type.append(4 - type.size(), ' ');
		value = s1 + type + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyborrowtime(int id, string borrowtime) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 22);
		s2 = value.substr(30, 50);
		borrowtime = borrowtime.append(8 - borrowtime.size(), ' ');
		value = s1 + borrowtime + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyreturntime(int id, string returntime) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 30);
		s2 = value.substr(38, 42);
		returntime = returntime.append(8 - returntime.size(), ' ');
		value = s1 + returntime + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyhistory(int id, string history) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 38);
		s2 = value.substr(78, 2);
		history = history.append(40 - history.size(), ' ');
		value = s1 + history + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}
bool bookdocking::bookmodifyonsheelf(int id, string onsheelf) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 78);
		s2 = value.substr(79, 1);
		onsheelf = onsheelf.append(1 - onsheelf.size(), ' ');
		value = s1 + onsheelf + s2;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}bool bookdocking::bookmodifyisovertime(int id, string isovertime) {
	if (bookdatabase.select(id, value)){
		value = value.substr(0, 80);
		string s1, s2;
		s1 = value.substr(0, 79);
		
		isovertime = isovertime.append(1 - isovertime.size(), ' ');
		value = s1 + isovertime;
		if (bookdatabase.update(id, value))
			return true;
		else
			return false;
	}
	else
		return false;
}



